# api/remote.py

from flask import Blueprint, render_template, request, jsonify, abort, current_app
from flask_login import login_required, current_user
from models import db, Residence, Relay, Plate, Log
from device_manager import RelayDevice

remote_bp = Blueprint('remote', __name__)


@remote_bp.route('/panel')
@login_required
def panel():
    return render_template('operator.html')


@remote_bp.route('/residences')
@login_required
def list_residences():
    data = []
    for r in Residence.query.all():
        plate = Plate.query.get(r.type) \
             or Plate.query.filter_by(description=r.type).first()
        if not plate:
            abort(500, f"Sin configuración de placa para tipo '{r.type}'")
        data.append({
            'id':   r.id,
            'name': r.name,
            'type': plate.identification
        })
    return jsonify(data)


@remote_bp.route('/residences/<res_id>/relays')
@login_required
def list_relays(res_id):
    rels = Relay.query.filter_by(residence_id=res_id).all()
    return jsonify([
        {'relay_id': r.relay_id, 'name': r.name, 'cmd_template': r.cmd_template}
        for r in rels
    ])


@remote_bp.route('/execute', methods=['POST'])
@login_required
def execute():
    js       = request.get_json() or {}
    res_id   = js.get('residence_id')
    relay_id = js.get('relay_id')
    action   = js.get('action')       # 'On' / 'Off'
    duration = js.get('duration', 0)  # segundos de pulso

    # 1) cargar residencia
    res = Residence.query.get(res_id)
    if not res:
        abort(404, "Residencia no encontrada")

    # 2) determinar placa
    plate = Plate.query.get(res.type) \
         or Plate.query.filter_by(description=res.type).first()
    if not plate:
        abort(500, f"Sin configuración de placa para tipo '{res.type}'")

    rels = Relay.query.filter_by(residence_id=res_id).all()

    # 3) armar configuración (usamos siempre el auth_pw de la BD)
    cfg = {
        'url_base': res.url_base,
        'type':      plate.identification,
        'auth':      {'username': res.auth_user, 'password': res.auth_pw}
                        if res.auth_user else {},
        'pw':        res.auth_pw,
        'relays':    [{'relay_id': r.relay_id, 'cmd_template': r.cmd_template}
                      for r in rels]
    }
    device = RelayDevice(cfg)

    # 4) ejecutar control + lectura (no interrumpimos al usuario)
    try:
        device.set_and_get_states(relay_id, action, duration)
    except Exception as exc:
        current_app.logger.warning(
            f"[REMOTE EXEC] fallo control {res_id}/{relay_id}: {exc!r}"
        )

    # 5) preparar curl mostrando la URL completa
    curl_cmd = f'curl "{device.last_control_url}"'

    # 6) persistir log
    log = Log(
        user=current_user.username,
        residence_id=res_id,
        relay_id=relay_id,
        action=action,
        duration=duration,
        result=curl_cmd
    )
    db.session.add(log)
    db.session.commit()

    return jsonify({'curl': curl_cmd})
