# app.py

from flask import Flask, redirect, url_for, abort
from flask_login import LoginManager, current_user
from flask_migrate import Migrate
from config import Config
from models import db, User
from api.auth import auth_bp
from api.remote import remote_bp

def setup_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Inicializar la base de datos
    db.init_app(app)
    # Inicializar migraciones
    Migrate(app, db)

    # Configurar Flask-Login
    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(username):
        return User.query.get(username)

    # Registrar blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(remote_bp, url_prefix='/api')

    # Ruta raíz → redirige según rol
    @app.route('/')
    def index():
        if current_user.is_authenticated:
            if current_user.role == 'operator':
                return redirect(url_for('remote.panel'))
            abort(403)
        return redirect(url_for('auth.login'))

    # Modo desarrollo
    app.config['DEBUG'] = True
    app.config['ENV'] = 'development'

    return app

# Crear la app de manera que Flask-Migrate / flask CLI puedan detectarla
app = setup_app()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=app.config['FLASK_PORT'])
