# config.py
import os
from pathlib import Path

class Config:
    # Ruta a la BD (puedes seguir usando DATABASE_URL)
    _db_path = os.getenv(
        'DATABASE_URL',
        str(Path(__file__).parent / 'SQLite' / 'data.db')
    )
    # Si no viene con el prefijo, lo a���adimos
    if not _db_path.startswith('sqlite:///'):
        _db_uri = f"sqlite:///{_db_path}"
    else:
        _db_uri = _db_path

    SQLALCHEMY_DATABASE_URI = _db_uri
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Resto de variables
    SECRET_KEY = os.getenv('SECRET_KEY', 'V1de0acces0s!')
    FLASK_PORT = int(os.getenv('FLASK_PORT', 5002))
