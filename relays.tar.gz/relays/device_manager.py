# device_manager.py

import re
import requests
from html.parser import HTMLParser
import xml.etree.ElementTree as ET
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth


class HTMLRelayParser(HTMLParser):
    """
    Parser de HTML genérico que busca <div id="tdX"><span>On/Off</span> para extraer estados.
    """
    def __init__(self):
        super().__init__()
        self.states = {}
        self._in_div = False
        self._cur_id = None
        self._in_span = False

    def handle_starttag(self, tag, attrs):
        if tag == 'div':
            for k, v in attrs:
                if k == 'id' and v.startswith('td'):
                    try:
                        self._cur_id = int(v[2:])
                        self._in_div = True
                    except ValueError:
                        pass
        elif self._in_div and tag == 'span':
            self._in_span = True

    def handle_data(self, data):
        if self._in_div and self._in_span and self._cur_id is not None:
            txt = data.strip().lower()
            if txt:
                self.states[self._cur_id] = 'On' if txt.startswith('on') else 'Off'

    def handle_endtag(self, tag):
        if tag == 'span':
            self._in_span = False
        elif tag == 'div':
            self._in_div = False
            self._cur_id = None


class RelayDevice:
    """
    Maneja múltiples tipos de tarjetas para controlar y leer estados de relés:
      - html, china, generic, xml, cgi, arduino

    cfg = {
      'url_base': str,
      'type':     'dingtian'|'smartden-16r'|'china'|'cgi'|'arduino'|'xml'|'generic',
      'auth':     {'username','password'} (opcional),
      'pw':       str               (opcional),
      'relays':   [ {'relay_id', 'cmd_template'} ... ]
    }
    """
    def __init__(self, cfg):
        self.url_base = cfg['url_base'].rstrip('/')
        self.dev_type = cfg['type'].lower()
        auth_cfg = cfg.get('auth') or {}
        if 'username' in auth_cfg and 'password' in auth_cfg:
            self.auth = HTTPBasicAuth(auth_cfg['username'], auth_cfg['password'])
        else:
            self.auth = None
        self.pw = cfg.get('pw', '')
        self.relays = cfg.get('relays', [])
        self.last_control_url = None

    def get_states(self):
        """Sólo lectura de estados (sin control)."""
        return self.set_and_get_states(None, None, 0)

    def set_and_get_states(self, relay_id, new_state, duration=0):
        """
        Controla (si relay_id,new_state != None) y retorna todos los estados.
        duration sólo usado en plantillas que lo requieran.
        """
        if self.dev_type == 'xml':
            return self._xml_cycle(relay_id, new_state)
        if self.dev_type == 'cgi':
            return self._cgi_cycle(relay_id, new_state)
        if self.dev_type == 'arduino':
            return self._arduino_cycle(relay_id, new_state)
        return self._html_cycle(relay_id, new_state, duration)

    def _html_cycle(self, relay_id, new_state, duration):
        # 1) Control
        if relay_id is not None and new_state is not None:
            entry = next((rl for rl in self.relays if rl['relay_id'] == relay_id), {})
            tpl = entry.get('cmd_template',
                            f"?relay={relay_id};st={1 if new_state=='On' else 0}")
            raw = tpl.format(
                type=self.dev_type,
                relay_id=relay_id,
                on=1 if new_state=='On' else 0,
                time=duration,
                pwd=self.pw
            )
            # Quitar el parámetro type=... si es Dingtian
            if self.dev_type == 'dingtian':
                raw = re.sub(r'([?&])type=[^&]*&?', r'\1', raw)

            # Construir la URL sin generar doble slash
            if raw.startswith('/'):
                url = f"{self.url_base}{raw}"
            else:
                url = f"{self.url_base}/{raw}"

            self.last_control_url = url
            try:
                requests.get(url, auth=self.auth, timeout=5).raise_for_status()
            except Exception:
                pass  # ignorar fallos de red en control

        # 2) Lectura estados
        try:
            resp = requests.get(self.url_base, auth=self.auth, timeout=5)
            resp.raise_for_status()
            text = resp.text
        except Exception:
            text = ''

        parser = HTMLRelayParser()
        parser.feed(text)
        states = parser.states.copy()

        # 3) Fallback china/generic
        if not states and self.dev_type in ('china', 'generic'):
            soup = BeautifulSoup(text, 'html.parser')
            for p in soup.find_all('p'):
                m = re.match(r'Relay\s*(\d+)\s*-\s*Estado\s*(\d+)', p.get_text(strip=True), re.I)
                if m:
                    idx, st = int(m.group(1)), int(m.group(2))
                    states[idx] = 'On' if st != 0 else 'Off'

        return states

    def _xml_cycle(self, relay_id, new_state):
        base = f"{self.url_base}/current_state.xml"
        if relay_id is not None and new_state is not None:
            params = {f"Relay{relay_id}": str(1 if new_state=='On' else 0)}
            if self.pw:
                params['pw'] = self.pw
            self.last_control_url = base + '?' + '&'.join(f"{k}={v}" for k, v in params.items())
            try:
                requests.get(base, params=params, auth=self.auth, timeout=5).raise_for_status()
            except Exception:
                pass

        try:
            resp = requests.get(base, auth=self.auth, timeout=5)
            resp.raise_for_status()
            root = ET.fromstring(resp.content)
        except Exception:
            return {}

        states = {}
        for node in root:
            if node.tag.startswith('Relay'):
                idx = int(node.tag.replace('Relay',''))
                val = node.findtext('State','0').strip()
                states[idx] = 'On' if val != '0' else 'Off'
        return states

    def _cgi_cycle(self, relay_id, new_state):
        if relay_id is not None and new_state is not None:
            prefix = 'relayon' if new_state == 'On' else 'relayoff'
            action = 'on' if new_state == 'On' else 'off'
            url = f"{self.url_base}/relay_en.cgi?{prefix}{relay_id}={action}"
            self.last_control_url = url
            try:
                requests.get(url, auth=self.auth, timeout=5).raise_for_status()
            except Exception:
                pass

        # lectura estados
        try:
            resp = requests.get(self.url_base, auth=self.auth, timeout=5)
            resp.raise_for_status()
            text = resp.text
        except Exception:
            text = ''

        states = {}
        soup = BeautifulSoup(text, 'html.parser')
        for p in soup.find_all('p'):
            m = re.match(r'Relay\s*(\d+)\s*-\s*Estado\s*(\d+)', p.get_text(strip=True), re.I)
            if m:
                idx, st = int(m.group(1)), int(m.group(2))
                states[idx] = 'On' if st != 0 else 'Off'
        return states

    def _arduino_cycle(self, relay_id, new_state):
        if relay_id is not None and new_state is not None:
            num = 1 if new_state == 'On' else 0
            url = f"{self.url_base}/?relay={relay_id};st={num}"
            self.last_control_url = url
            try:
                requests.get(url, auth=self.auth, timeout=5).raise_for_status()
            except Exception:
                pass

        try:
            resp = requests.get(self.url_base, auth=self.auth, timeout=5)
            resp.raise_for_status()
            text = resp.text
        except Exception:
            text = ''

        states = {}
        soup = BeautifulSoup(text, 'html.parser')
        for p in soup.find_all('p'):
            m = re.match(r'Relay\s*(\d+)\s*-\s*Estado\s*(\d+)', p.get_text(strip=True), re.I)
            if m:
                idx, st = int(m.group(1)), int(m.group(2))
                states[idx] = 'On' if st != 0 else 'Off'
        return states
