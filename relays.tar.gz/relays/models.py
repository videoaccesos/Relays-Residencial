from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    username = db.Column(db.String, primary_key=True)
    password = db.Column(db.String, nullable=False)
    role     = db.Column(db.String, nullable=False)

    def get_id(self):
        return self.username

class Plate(db.Model):
    __tablename__ = 'plates'
    identification = db.Column(db.String, primary_key=True)
    description    = db.Column(db.String)
    url_template   = db.Column(db.String, nullable=False)

class Residence(db.Model):
    __tablename__ = 'residences'
    id        = db.Column(db.String, primary_key=True)
    name      = db.Column(db.String)
    url_base  = db.Column(db.String)
    type      = db.Column(db.String)
    dyndns    = db.Column(db.String)

    # ← NUEVAS COLUMNAS PARA CREDENCIALES
    auth_user = db.Column(db.String, nullable=True)
    auth_pw   = db.Column(db.String, nullable=True)

class Relay(db.Model):
    __tablename__ = 'relays'
    id           = db.Column(db.Integer, primary_key=True)
    residence_id = db.Column(
        db.String,
        db.ForeignKey('residences.id'),
        nullable=False
    )
    relay_id     = db.Column(db.Integer, nullable=False)
    name         = db.Column(db.String,  nullable=False)
    cmd_template = db.Column(db.String,  nullable=False)

class Log(db.Model):
    __tablename__ = 'logs'
    id           = db.Column(db.Integer, primary_key=True)
    ts           = db.Column(db.DateTime)
    user         = db.Column(db.String)
    residence_id = db.Column(db.String)
    relay_id     = db.Column(db.Integer)
    action       = db.Column(db.String)
    duration     = db.Column(db.Integer)
    result       = db.Column(db.Text)
