#!/usr/bin/env python
# seed_from_csv.py

import pandas as pd
from app import setup_app
from models import db, Residence, Relay, Plate

# Mapea "Tipo de Tarjeta" → (plate_id, cmd_template)
PLATE_TEMPLATES = {
    'Dingtian':      ('dingtian',     '/relay_cgi.cgi?relay={relay_id}&on={on}&time={time}&pwd={pwd}'),
    'SmartDen-16R':  ('smartden-16r', '/current_state.xml?pw={pwd}&Relay{relay_id}={state}'),
    'Panel Chino':   ('china',        '/?relay={relay_id}&st={state}'),
    'Relay_control': ('cgi',          '/relay_en.cgi?relayon{relay_id}=on'),
    'arduino':       ('arduino',      '/?relay={relay_id};st={state}')
}

CSV_PATH = 'Relacion de Relays.csv'


def sync_plates():
    """Crea o actualiza las plantillas en plates."""
    for tipo, (pid, tmpl) in PLATE_TEMPLATES.items():
        plate = Plate.query.get(pid)
        if not plate:
            plate = Plate(
                identification=pid,
                description=tipo,
                url_template=tmpl
            )
            db.session.add(plate)
        else:
            plate.url_template = tmpl
    db.session.commit()


def main():
    app = setup_app()
    with app.app_context():
        # 1) Sincronizamos plates
        sync_plates()

        # 2) Leemos el CSV
        df = pd.read_csv(CSV_PATH, encoding='latin1')
        df.columns = df.columns.str.strip()
        required = {'Privada', 'auth_user', 'dyndns', 'Tipo de Tarjeta', 'auth_pw'}
        if not required.issubset(df.columns):
            missing = required - set(df.columns)
            raise RuntimeError(f"Faltan columnas en el CSV: {missing}")

        # 3) Iteramos cada fila
        for _, row in df.iterrows():
            priv = row['Privada']
            dyn  = row['dyndns']
            tipo = row['Tipo de Tarjeta']
            usr  = row.get('auth_user', '')
            pwd  = row.get('auth_pw', '')

            # 3a) Crear o actualizar Residence
            url_base = f'http://{dyn}'
            res = Residence.query.get(priv)
            if not res:
                res = Residence(
                    id        = priv,
                    name      = priv,
                    type      = tipo,
                    url_base  = url_base,
                    dyndns    = dyn,
                    auth_user = usr,
                    auth_pw   = pwd
                )
                db.session.add(res)
            else:
                res.name       = priv
                res.type       = tipo
                res.url_base   = url_base
                res.dyndns     = dyn
                res.auth_user  = usr
                res.auth_pw    = pwd
            db.session.flush()

            # 4) Crear nuevos Relays
            plate_id, tmpl = PLATE_TEMPLATES[tipo]
            for i in range(1, 17):
                nombre = (row.get(f'Relay {i}', '') or '').strip()
                if nombre and nombre.lower() != 'nada':
                    exists = Relay.query.filter_by(
                        residence_id=priv,
                        relay_id    = i
                    ).first()
                    if not exists:
                        db.session.add(Relay(
                            residence_id = priv,
                            relay_id     = i,
                            name         = nombre,
                            cmd_template = tmpl
                        ))

        # 4.5) **Sincronizar cmd_template de todos los relés existentes**
        for res in Residence.query.all():
            _, tmpl = PLATE_TEMPLATES[res.type]
            Relay.query.filter_by(residence_id=res.id) \
                       .update({'cmd_template': tmpl})

        # 5) Commit final
        db.session.commit()
        print("✅ Datos inyectados correctamente.")


if __name__ == '__main__':
    main()
