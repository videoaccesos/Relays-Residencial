#!/usr/bin/env bash

# Script de instalación para la aplicación Flask en el entorno 'relays'.
# Asume que el entorno virtual 'relays' ya existe.
set -euo pipefail

# 1. Activar entorno virtual existente
echo "Activando entorno virtual 'relays'..."
source relays/bin/activate

# 2. Actualizar pip e instalar / actualizar requerimientos
echo "Instalando dependencias desde requirements.txt..."
pip install --upgrade pip
pip install -r requirements.txt

echo "Dependencias instaladas en el entorno 'relays'."

# 3. Variables de entorno recomendadas
cat <<EOF
# Define estas variables en tu shell o .env:
export FLASK_ENV=production
export FLASK_CONFIG=config.yaml
export FLASK_PORT=5002        # Puerto para esta aplicación
export WATCHDOG_INTERVAL=60   # Segundos entre checks de salud
export WATCHDOG_THRESHOLD=120 # Segundos de umbral de alerta de watchdog
EOF

echo "Recuerda: activa el entorno con 'source relays/bin/activate' antes de ejecutar python si cierras y abres la terminal."```

# requirements.txt
```text
Flask>=2.0
Flask-APScheduler>=1.12
PyYAML>=6.0
SQLAlchemy>=1.4
requests>=2.26
