// static/js/remote.js

const API_BASE  = '/api';
const DURATIONS = [2, 15];  // segundos de pulso

window.addEventListener('DOMContentLoaded', () => {
  const sel     = document.getElementById('residence-select');
  const nextBtn = document.getElementById('next-residence');

  // 1) cargar residencias (incluye cookies de sesión)
  fetch(`${API_BASE}/residences`, {
    credentials: 'same-origin'
  })
    .then(r => {
      if (!r.ok) throw new Error(`Error cargando residencias (${r.status})`);
      return r.json();
    })
    .then(data => {
      sel.innerHTML = '';  // limpia opciones previas
      data.forEach(r => {
        const opt = document.createElement('option');
        opt.value        = r.id;
        opt.textContent  = r.name.toUpperCase();
        opt.dataset.type = r.type;   // guardamos plate_id
        sel.appendChild(opt);
      });
      sel.selectedIndex = 0;
      loadRelays();
    })
    .catch(err => console.error(err));

  sel.addEventListener('change', loadRelays);
  nextBtn.addEventListener('click', () => {
    sel.selectedIndex = (sel.selectedIndex + 1) % sel.options.length;
    loadRelays();
  });
});

function loadRelays() {
  const sel   = document.getElementById('residence-select');
  const resId = sel.value;

  fetch(`${API_BASE}/residences/${resId}/relays`, {
    credentials: 'same-origin'
  })
    .then(r => {
      if (!r.ok) throw new Error(`Error cargando relés (${r.status})`);
      return r.json();
    })
    .then(relays => {
      const panel = document.getElementById('relay-panel');
      panel.innerHTML = '';

      relays.forEach(r => {
        let state = r.state || 'Off';

        // fila
        const item = document.createElement('div');
        item.className = 'list-group-item mb-2';
        const row = document.createElement('div');
        row.className = 'row align-items-center';

        // Columna 1: nombre
        const colName = document.createElement('div');
        colName.className = 'col-3';
        colName.innerHTML = `<strong>${r.name.toUpperCase()}</strong>`;
        row.appendChild(colName);

        // Columna 2: toggle
        const colT = document.createElement('div');
        colT.className = 'col-5';
        const btnT = document.createElement('button');
        btnT.classList.add('btn','btn-sm');
        const upd = () => {
          if (state === 'Off') {
            btnT.textContent = 'ACTIVAR';
            btnT.classList.replace('btn-danger','btn-success');
          } else {
            btnT.textContent = 'DESACTIVAR';
            btnT.classList.replace('btn-success','btn-danger');
          }
        };
        upd();
        btnT.onclick = () => {
          const act = state === 'Off' ? 'On' : 'Off';
          execute(resId, r.relay_id, act, 0)
            .then(() => { state = act; upd(); })
            .catch(err => console.error(err));
        };
        colT.appendChild(btnT);
        row.appendChild(colT);

        // Columnas siguientes: 2 SEG y 15 SEG
        DURATIONS.forEach((d, i) => {
          const col = document.createElement('div');
          col.className = 'col-2';
          const btn = document.createElement('button');
          btn.className = 'btn btn-outline-primary btn-sm w-100';
          btn.textContent = `${d} SEG`;
          btn.onclick = () => execute(resId, r.relay_id, 'On', d)
                            .catch(err => console.error(err));
          col.appendChild(btn);
          row.appendChild(col);
        });

        item.appendChild(row);
        panel.appendChild(item);
      });
    })
    .catch(err => console.error(err));
}

function execute(resId, relayId, action, duration = 0) {
  const payload = {
    residence_id: resId,
    relay_id:     relayId,
    action,
    duration
  };
  return fetch(`${API_BASE}/execute`, {
    method:      'POST',
    credentials: 'same-origin',
    headers:     {'Content-Type':'application/json'},
    body:        JSON.stringify(payload)
  })
  .then(r => {
    if (!r.ok) throw new Error(`Error al ejecutar (${r.status})`);
    return r.json();
  })
  .then(json => {
    const out = document.getElementById('curl-output');
    if (out) out.textContent = json.curl;
    return json;
  });
}
